﻿using System;
using System.Collections.Generic;

namespace Admin.Model
{
    public partial class Loan
    {
        public int LoanId { get; set; }
        public string LoanType { get; set; } = null!;
        public int UserId { get; set; }
        public decimal Amount { get; set; }
        public decimal RateOfIntrest { get; set; }
        public int LoanPeriod { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }

        public virtual User User { get; set; } = null!;
    }
}
