﻿
namespace Admin.Controllers
{
    public class AdminController
    {
    }
}
