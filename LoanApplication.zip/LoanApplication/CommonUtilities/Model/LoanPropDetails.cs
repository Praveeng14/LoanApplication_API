﻿namespace CommonUtilities.Model
{
    public class LoanPropDetails
    {
        public int PropertyId { get; set; }
        public string PropertyDescription { get; set; } = null!;
        public string Propertyaddress { get; set; } = null!;
        public string PropertyCity { get; set; } = null!;
        public string PropertState { get; set; } = null!;
        public byte[]? PropertyImage { get; set; }
        public int LoanNumber { get; set; }
        public string PropertyDetails { get; set; } = null!;
        public string LoanDetails { get; set; } = null!;
    }
}
