﻿namespace CommonUtilities.Model
{
    public class searchloanprop
    {

        public int LoanNumber { get; set; }
        public string LoanType { get; set; }
    }
}
