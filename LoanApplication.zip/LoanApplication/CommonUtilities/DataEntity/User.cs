﻿using System;
using System.Collections.Generic;

namespace CommonUtilities.DataEntity
{
    public partial class User
    {
        //public User()
        //{
        //    Loans = new HashSet<Loan>();
        //}

        public int UserId { get; set; }
        public string UserName { get; set; } = null!;
        public int UserRoleId { get; set; }
        public string Email { get; set; } = null!;
        public string Pasword { get; set; } = null!;
        public string ContactNo { get; set; } = null!;
        public string Addres { get; set; } = null!;
        public string State { get; set; } = null!;
        public string City { get; set; } = null!;
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }

        //public virtual Role UserRole { get; set; } = null!;
        //public virtual ICollection<Loan> Loans { get; set; }
    }
}
