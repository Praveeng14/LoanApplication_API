﻿using System;
using System.Collections.Generic;

namespace CommonUtilities.DataEntity
{
    public partial class Loan
    {
        //public Loan()
        //{
        //    //LoanProperties = new HashSet<LoanProperty>();
        //}

        public int LoanNumber { get; set; }
        public string LoanType { get; set; } = null!;
        public int UserId { get; set; }
        public decimal LoanAmount { get; set; }
        public decimal RateOfIntrest { get; set; }
        public int LoanPeriod { get; set; }
        public DateTime OriginationDate { get; set; }
        public DateTime ModifiedDate { get; set; }

        //public virtual User User { get; set; } = null!;
        //public virtual ICollection<LoanProperty> LoanProperties { get; set; }
    }
}
