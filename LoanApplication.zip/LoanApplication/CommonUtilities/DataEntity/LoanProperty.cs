﻿using System;
using System.Collections.Generic;

namespace CommonUtilities.DataEntity
{
    public partial class LoanProperty
    {
        public int PropertyId { get; set; }
        public string PropertyDescription { get; set; } = null!;
        public string Propertyaddress { get; set; } = null!;
        public string PropertyCity { get; set; } = null!;
        public string PropertState { get; set; } = null!;
        public byte[]? PropertyImage { get; set; }
        public int LoanNumber { get; set; }
        public string PropertyDetails { get; set; } = null!;
        public string LoanDetails { get; set; } = null!;

        //public virtual Loan LoanNumberNavigation { get; set; } = null!;
    }
}
