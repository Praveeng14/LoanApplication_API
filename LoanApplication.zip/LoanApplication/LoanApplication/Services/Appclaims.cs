﻿using System.Security.Claims;
namespace LoanApplication.Services
{
    public class Appclaims
    {
        private ClaimsIdentity identity;

        public Appclaims(ClaimsIdentity identity)
        {
           
        }

        public string UserType { get; set; }
        public string AuthorName { get; set; }
        public string UserName { get; set; }


        public int UserId { get; set; }
       
        public int UserRoleId { get; set; }
    }
}
