﻿using CommonUtilities.DataEntity;
using CommonUtilities.Model;

namespace LoanApplication.Services
{
    public interface IAdminService
    {
        LoanAppContext dbContext { get; set; }

        string AddLoanProperty(LoanProperty loanProperty);
        string CreateLoan(Loan loan);
        List<Loan> GetAllLoans();
        IEnumerable<Loan> GetLoansbyid(int loannumber);
        List<LoanDetails> Searchbyloan(searchloanprop searchLoanFields);
        string UpdateLoan(LoanDetails loandetails);
        string UpdateLoanProperty(LoanPropDetails loanPropDetails);
    }
}