﻿using System.Security.Claims;
using CommonUtilities.Model;
using CommonUtilities.DataEntity;
namespace LoanApplication.Services
{
    public class AdminService : IAdminService
    {
        public LoanAppContext dbContext { get; set; }

        public AdminService(LoanAppContext loanAppContext)
        {
            dbContext = loanAppContext;
        }
        //---------------For Displaying All Loans 
        public List<Loan> GetAllLoans()
        {
            List<Loan> loanList = new List<Loan>();
            var entityAll = dbContext.Loans;

            foreach (var item in entityAll)
            {
                Loan LoanDetails = new Loan();
                LoanDetails.LoanType = item.LoanType;
                LoanDetails.LoanPeriod = item.LoanPeriod;
                LoanDetails.LoanNumber = item.LoanNumber;
                LoanDetails.RateOfIntrest = item.RateOfIntrest;
                LoanDetails.OriginationDate = item.OriginationDate;
                LoanDetails.UserId = item.UserId;
                loanList.Add(LoanDetails);

            }
            return loanList;
        }

        public string CreateLoan(Loan loan)
        {
            try
            {
                Loan LoanEntity = new Loan();
                LoanEntity.UserId = loan.UserId;
                LoanEntity.LoanType = loan.LoanType;
                LoanEntity.RateOfIntrest = loan.RateOfIntrest;
                LoanEntity.LoanAmount = loan.LoanAmount;
                LoanEntity.LoanPeriod=loan.LoanPeriod;
                LoanEntity.OriginationDate = loan.OriginationDate;
                LoanEntity.LoanNumber = loan.LoanNumber;
                LoanEntity.ModifiedDate = loan.ModifiedDate;
                //LoanEntity.LoanProperties = loan.LoanProperties;
                dbContext.Loans.Add(LoanEntity);
                dbContext.SaveChanges();
                return "Loan Added Successfully";


                    //dbContext.Books.Add(bookEntity);
                    //dbContext.SaveChanges();
                    //return "Book added successfully";

            }
            catch (Exception)
            {
                return "Some error occurred";
            }
        }

        public string UpdateLoan(LoanDetails loandetails)
        {
            try
            {
                var Loanupdate = dbContext.Loans.FirstOrDefault(x => x.LoanNumber == loandetails.LoanNumber);
                if (Loanupdate != null)
                {
                    Loanupdate.LoanAmount = loandetails.LoanAmount;
                    Loanupdate.LoanPeriod = loandetails.LoanPeriod;
                    Loanupdate.RateOfIntrest = loandetails.RateOfIntrest;
                    Loanupdate.ModifiedDate = DateTime.Now;
                   
                    dbContext.SaveChanges();
                    return "Edited loan successfully";
                }
                else
                {
                    return "Loan Not found";
                }
            }
            catch (Exception)
            {
                return "Error occurred in edit loan";
            }
        }


        public string AddLoanProperty(LoanProperty loanProperty)
        {
            try
            {
                LoanProperty LoanPropEntity = new LoanProperty();
                LoanPropEntity.PropertyDescription=loanProperty.PropertyDescription;
                
                LoanPropEntity.Propertyaddress = loanProperty.Propertyaddress;
                LoanPropEntity.PropertyCity = loanProperty.PropertyCity;
                LoanPropEntity.PropertState = loanProperty.PropertState;
                LoanPropEntity.PropertyImage=loanProperty.PropertyImage;
                
                LoanPropEntity.LoanNumber = loanProperty.LoanNumber;
                LoanPropEntity.PropertyDetails = loanProperty.PropertyDetails;
                LoanPropEntity.LoanDetails = loanProperty.LoanDetails;
               
                dbContext.LoanProperties.Add(LoanPropEntity);
                dbContext.SaveChanges();
                return "Loan Added Successfully";


                //dbContext.Books.Add(bookEntity);
                //dbContext.SaveChanges();
                //return "Book added successfully";

            }
            catch (Exception)
            {
                return "Some error occurred";
            }
        }

        public string UpdateLoanProperty(LoanPropDetails loanPropDetails)
        {
            try
            {
                var Loanpropupdate = dbContext.LoanProperties.FirstOrDefault(x => x.PropertyId == loanPropDetails.PropertyId);
                if (Loanpropupdate != null)
                {
                    Loanpropupdate.Propertyaddress=loanPropDetails.Propertyaddress;
                    Loanpropupdate.PropertyDescription=loanPropDetails.PropertyDescription;
                    Loanpropupdate.PropertyCity = loanPropDetails.PropertyCity;
                    Loanpropupdate.PropertState=loanPropDetails.PropertState;
                    Loanpropupdate.PropertyDetails=loanPropDetails.PropertyDetails;
                   

                    dbContext.SaveChanges();
                    return "Edited loanproperty successfully";
                }
                else
                {
                    return "Loan Not found";
                }
            }
            catch (Exception)
            {
                return "Error occurred in edit loanprop";
            }
        }

        public List<LoanDetails> Searchbyloan(searchloanprop searchLoanFields)
        {
            List<LoanDetails> loanList = new List<LoanDetails>();
            if (!string.IsNullOrEmpty(searchLoanFields.LoanType) || searchLoanFields.LoanNumber.Equals(null))
            {
                var entity = dbContext.Loans.Where(b => b.LoanType == searchLoanFields.LoanType
                    || b.LoanNumber == searchLoanFields.LoanNumber);

                foreach (var item in entity)
                {
                    LoanDetails loanDetails = new LoanDetails();
                    loanDetails.LoanType = item.LoanType;
                    loanDetails.LoanNumber = item.LoanNumber;
                    loanDetails.LoanPeriod = item.LoanPeriod;
                    loanDetails.RateOfIntrest = item.RateOfIntrest;
                    loanDetails.OriginationDate = item.OriginationDate;

                    loanList.Add(loanDetails);
                }

                return loanList;
            }


            return loanList;

        }

        public IEnumerable<Loan> GetLoansbyid(int loannumber)
        {
            var request = dbContext.Loans.Where(x => x.LoanNumber == loannumber);
            return request;
        }



    }
}
