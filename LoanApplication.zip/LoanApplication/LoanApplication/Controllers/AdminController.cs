﻿using CommonUtilities.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using LoanApplication.Services;
using CommonUtilities.DataEntity;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query.Internal;
using CommonUtilities.Model;
using System.Security.Claims;


namespace LoanApplication.Controllers
{
   
    [ApiController]
    [Route("[controller]/[action]")]
    public class AdminController : Controller
    {

        private readonly LoanAppContext _context;

        public AdminController(LoanAppContext context, IAdminService adminService)
        {
            _context = context;
            _adminService = adminService;
        }

        private readonly IAdminService _adminService;

        //public AdminController(IAdminService adminService)
        //{
        //    _adminService = adminService;
        //}
        [HttpGet]
        public JsonResult DisplayLoans()
        {
            try
            {
                var loaans = _adminService.GetAllLoans();
                if (loaans.Count == 0)
                {
                    return Json(NotFound("No loan found change the filters and try "));
                }
                return Json(loaans);
            }
            catch (Exception)
            {
                return Json("Some error occurred");
            }
        }
        //------------For Admin Get All Loans Records
        [HttpGet("GetAllLoans")]
        public async Task<ActionResult<List<Loan>>> GetAllLoans()
        {
            try { 
            var result = await _context.Loans.FromSqlRaw("SP_Loans").ToListAsync();

          
              return Ok(new
                {
                    result = result
                    
                });
            }
            catch (Exception)
            {
                return Json("Some error occurred");
            }
        }
        //-----------For Customer Loan Records Getting By Id----------
        [HttpGet("{userId}")]
        public async Task<ActionResult<List<Loan>>> GetLoansById(int userId)
        {
            try {
                var result = await _context.Loans.FromSqlRaw($"GETLOANS {userId}").ToListAsync();

                return Ok(new
                {
                    result = result

                });
            }
            
             catch (Exception)
            {
                return Json("Some error occurred");
            }
        }
        //public IQueryable<Customer> SearchCustomers(string contactName)
        //{
        //    SqlParameter pContactName = new SqlParameter("@ContactName", contactName);
        //    return this.Customers.FromSql("EXECUTE Customers_SearchCustomers @ContactName", pContactName);
        //}
        //[HttpPost]
        //public async Task<ActionResult<int>> insertloan([FromBody] LoanDetails loan)
        //{
        //    try {
        //    var result = await _context.Database
        //        .ExecuteSqlRawAsync($"STP_LOAN_DETAILS {loan}");
        //        return Ok(result);
        //    }
        //    catch (Exception) {
        //        return Json("failed");
        //    }

        //}

        [HttpPost]
        public ActionResult CreateLoan([FromBody]Loan loan)
        {
            try
            {
                string result = _adminService.CreateLoan(loan);
                return Ok(new
                {
                    Result = result

                });
            }
            catch (Exception)
            {
                return Json("Exception Occured");
            }
        }

        [HttpPut]
        public ActionResult<string> EditLoan([FromBody] LoanDetails loanDetails)
        {
            try
            {
                string result = _adminService.UpdateLoan(loanDetails);
               
                return Ok(new
                {
                    result = result

                });
            }
            catch (Exception)
            {
                return Json("Exception Occured");
            }
        }


        [HttpPost]
        public JsonResult AddLoanPropert([FromBody] LoanProperty loanProperty)
        {
            try
            {
                string result = _adminService.AddLoanProperty(loanProperty);
                return Json(result);
            }
            catch (Exception)
            {
                return Json("Exception Occured");
            }
        }

        [HttpPut]
        public ActionResult<string> EditLoanProp([FromBody] LoanPropDetails loanPropDetails)
        {
            try
            {
                string result = _adminService.UpdateLoanProperty(loanPropDetails);
                return Ok(result);
            }
            catch (Exception)
            {
                return Json("Exception Occured");
            }
        }

        [HttpGet("(loannumber)")]
        public async Task<ActionResult<List<Loan>>> GetLoansByLoanId(int loannumber)
        {
            try
            {
                var result = await _context.Loans.FromSqlRaw($"[GETLOANSByLoanId] {loannumber}").ToListAsync();

                return Ok(new
                {
                    result = result

                });
            }

            catch (Exception)
            {
                return Json("Some error occurred");
            }
        }


        [HttpGet]
        public async Task<ActionResult<List<Loan>>> GetLoansById1(int userId)
        {
            try
            {
                var identity = HttpContext.User.Identity as ClaimsIdentity;
                if (identity != null)
                {
                    Appclaims appclaims = new Appclaims(identity);
                    //var result = await _context.Loans.FromSqlRaw($"GETLOANS {userId}").ToListAsync();

                    //if (!string.IsNullOrWhiteSpace(appclaims.UserId))
                    //    return _authorService.GetAllBooks(appclaims.AuthorName);

                    //return Ok(new
                    //{
                    //    result = result

                    //});


                }


                var result = await _context.Loans.FromSqlRaw($"GETLOANS {userId}").ToListAsync();

                return Ok(new
                {
                    result = result

                });
            }

            catch (Exception)
            {
                return Json("Some error occurred");
            }
        }



    }
}
