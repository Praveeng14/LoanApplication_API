﻿namespace LoanApplication.Controllers
{
    public class CustomerController
    {

    }
}
